# Copyright (c) 2017, Frappe Technologies Pvt. Ltd. and Contributors
# See license.txt

import unittest


class TestPaymentTerm(unittest.TestCase):
	pass
